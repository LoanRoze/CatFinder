<?php

function safeText($string) {
    return htmlspecialchars($string);
}