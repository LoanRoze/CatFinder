<section class="privacy-policy">
  <div class="container">
    <h1>Politique de confidentialité</h1>
    <p>Nous prenons la confidentialité de vos données très au sérieux. Voici un aperçu de notre politique de confidentialité :</p>
    <ul>
      <li>Types de données collectées : nom, email, numéro de téléphone</li>
      <li>Utilisation des données collectées</li>
      <li>Mesures de sécurité mises en place pour protéger vos données</li>
    </ul>
    <p>Nous nous engageons à protéger vos informations personnelles conformément aux lois en vigueur.</p>
  </div>
</section>