<section class="postAnnoncement">
    <h1>Quel type d'annonce voulez-vous publier ?</h1>
    <div id="container">
        <a href="index.php?page=postFoundCat">
            <div class="card">
                <div class="card-image">
                    <img src="./assets/good.png" alt="Chat trouvé" />
                </div>
                <div class="card-content">
                    J'ai trouvé un chat
                </div>
            </div>
        </a>
        <a href="index.php?page=postLostCat">
            <div class="card">
                <div class="card-image">
                    <img id="imgcat" src="./assets/notgood.png" alt="Chat perdu" />
                </div>
                <div class="card-content">
                    J'ai perdu mon chat
                </div>
            </div>
        </a>
    </div>
</section>