<section class="legal-mentions">
    <div class="container">
        <h1>Mentions légales :</h1>
        <ul>
            <li>Techtwins Corporation</li>
            <li>techtwins.fr</li>
            <li>Loan Roze</li>
            <li>Ryan Yovo Valéry</li>
        </ul>
        <p>Ces informations sont obligatoires conformément aux lois applicables.</p>
    </div>
</section>