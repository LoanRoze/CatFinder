document
  .getElementById("fileuploaderinput")
  .addEventListener("click", () => {
    document.getElementById("fileuploader").click();
  });
