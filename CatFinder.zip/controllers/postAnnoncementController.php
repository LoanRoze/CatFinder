<?php

$template = 'views/pages/postAnnoncement.php';