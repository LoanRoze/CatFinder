<?php

$template = 'views/pages/legal-mentions.php';

