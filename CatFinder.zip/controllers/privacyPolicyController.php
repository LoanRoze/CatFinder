<?php

$template = 'views/pages/privacy-policy.php';

