<?php 

require('router.php');
require('views/layout.php');